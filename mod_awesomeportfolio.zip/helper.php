﻿<?php
/**
* @Author  Mostafa Shahiri
*@license	GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
defined('_JEXEC') or die();
 if(!class_exists('ContentHelperRoute'))
 require_once (JPATH_SITE . '/components/com_content/helpers/route.php');

class modAwesomeportfolioHelper{

static function getArticles($params,$new_count='')
    {
    $cats =$params->get('cats',array());
    $users =$params->get('users',array());
    $alltags =$params->get('alltags',array());
    $order=$params->get('order','created');
    $sort=$params->get('sort','DESC');
    $count=$params->get('count',5);
    $filter=$params->get('filter');
    $new_count=(int)$new_count;
    if(!empty($new_count))
    $count=$new_count+$count;
    $db=JFactory::getDBO();
    $user = JFactory::getUser();
    $tag = JFactory::getLanguage()->getTag();
    $nullDate = $db->getNullDate();
    $tag_table=(!empty($alltags))?',#__contentitem_tag_map t':'';
    $query='SELECT DISTINCT m.id,m.catid,m.title,m.created_by as userid,m.introtext,m.images,m.created,m.modified,s.name as author, c.title as catname FROM #__content m,#__categories c,#__users s'.$tag_table.' WHERE m.state=1 AND m.catid=c.id AND m.created_by=s.id AND (m.publish_up = '.$db->Quote($nullDate).' OR m.publish_up <= NOW() ) AND (m.publish_down = '.$db->Quote($nullDate).' OR m.publish_down >= NOW()) AND m.language IN ("'.$tag.'","*") AND m.access IN ('.implode(',', $user->getAuthorisedViewLevels()).')';
    if(!empty($cats))
    $query.='AND m.catid IN ('.implode(',',$cats).') ';
    if(!empty($users))
    $query.='AND m.created_by IN ('.implode(',',$users).') ';
     if(!empty($alltags))
    $query.='AND m.id = t.content_item_id AND t.tag_id IN ('.implode(',',$alltags).') ';
    if(!empty($order))
    $query.='ORDER BY '.$order.' ';
    if(!empty($sort))
    $query.=$sort;
    if(!empty($count))
     $query.=' LIMIT '.(int)$count;
    $db->setQuery($query);
    $result=$db->loadObjectList();
    foreach($result as $r){
     if($filter==1)
      {
       $r->classname=(empty($r->classname))?'modcolumn class'.$r->catid:$p->classname.' class'.$r->catid;
      }
      else if($filter==2)
      {
        $r->classname=(empty($r->classname))?'modcolumn class'.$r->userid:$r->classname.' class'.$r->userid;
      }
      else if($filter==3)
      {  $tagsid=self::getTagsByArticleId($r->id);
       foreach($tagsid as $t)
       $r->classname=(empty($r->classname))?'modcolumn class'.$t->tagid:$r->classname.' class'.$t->tagid;
      }
      }
     return $result;
}
static function getTagsByArticleId($tagid){
 $db=JFactory::getDBO();
 $query='SELECT t.tag_id as tagid FROM #__contentitem_tag_map t WHERE t.content_item_id='.$tagid;
 $db->setQuery($query);
 $result=$db->loadObjectList();
 return $result;
}
static function getSource($params){
     $cats =$params->get('cats',array());
    $users =$params->get('users',array());
    $tags =$params->get('alltags',array());
    $filter =(int)$params->get('filter');
    $db=JFactory::getDBO();
     if($filter==1)
      {
       $query='SELECT c.id, c.title as title FROM #__categories c WHERE c.id IN ('.implode(',',$cats).') ';
      }
      else if($filter==2)
      {
        $query='SELECT s.id, s.name as title FROM #__users s WHERE s.id IN ('.implode(',',$users).') ';
      }
      else if($filter==3)
      { $query='SELECT t.id, t.title as title FROM #__tags t WHERE t.id IN ('.implode(',',$tags).') ';
      }
     $db->setQuery($query);
    $result=$db->loadObjectList();
    return $result;
}
static function getAjax(){

   $input = JFactory::getApplication()->input;
   $count  = $input->get('portcount', '', 'INT');
   jimport('joomla.application.module.helper');
   $module = JModuleHelper::getModule('mod_awesomeportfolio');
   $moduleParams = new JRegistry;
   $moduleParams->loadString($module->params);
   $category=$moduleParams->get('catshow',0);
   $author=$moduleParams->get('showauthor',0);
   $date=$moduleParams->get('showcreate',0);
   $modified=$moduleParams->get('showmodified',0);
   $desc=$moduleParams->get('intro',0);
   $morebtn=$moduleParams->get('showreadmore',0);
   $limit=(int)$moduleParams->get('limit',20);
   $result= self::getArticles($moduleParams,$count);
   $output='';
   if(!empty($result))
{
 foreach($result as $c)
{
  $images = json_decode($c->images);
  $c_tmp=($category==1)?'<small class="modportinfo">'.JText::_('MOD_AWESOMEPORTFOLIO_CAT').'</small>: <small class="modport_cats">'.$c->catname.'</small></br>':'';
  $a_tmp=($author==1)?'<small class="modportinfo">'.JText::_('MOD_AWESOMEPORTFOLIO_AUTHOR').': '.$c->author.'</small></br>':'';
  $d_tmp=($date==1)?'<small class="modportinfo">'.JText::_('MOD_AWESOMEPORTFOLIO_CREATED').': '.JHtml::_('date',$c->created, JText::_('DATE_FORMAT_LC3')).'</small></br>':'';
  $m_tmp=($modified==1)?'<small class="modportinfo">'.JText::_('MOD_AWESOMEPORTFOLIO_MODIFIED').': '.JHtml::_('date',$c->modified, JText::_('DATE_FORMAT_LC3')).'</small></br>':'';
  $desc_tmp=($desc==1)?'<div>'.JHTML::_('string.truncate',$c->introtext,$limit).'</div>':'';
  $morebtn_tmp= ($morebtn==1)?'<a class="modport_readmore" href="'.JRoute::_(ContentHelperRoute::getArticleRoute($c->id,$c->catid)).'">'.JText::_('MOD_AWESOMEPORTFOLIO_READMORE').'</a>':'';
  $info_block=(!empty($c_tmp.$a_tmp.$d_tmp.$m_tmp))?'<div class="infoblock">'.$c_tmp.$a_tmp.$d_tmp.$m_tmp.'</div>':'';

  $output.='<div class="'.$c->classname.'">';
  $output.='<div class="modport_content"><div class="modport_container">'.'<div class="modport_img"><img src="'.htmlspecialchars($images->image_intro).'"/></div>'.'<div class="modport_overlay"><a class="modport_imglink" href="'.JRoute::_(ContentHelperRoute::getArticleRoute($c->id,$c->catid)).'"></a></div></div>'.$info_block.'<h4>'.$c->title.'</h4>'.$desc_tmp.$morebtn_tmp;
  $output.='</div>';
  $output.='</div>';

}

}
return $output;

}

}