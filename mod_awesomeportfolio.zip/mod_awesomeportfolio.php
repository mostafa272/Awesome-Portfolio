﻿<?php
/**
* @Author  Mostafa Shahiri
*@license	GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
defined('_JEXEC') or die();
if(!defined('DS'))
{  define('DS',DIRECTORY_SEPARATOR);
}
// Include the helper class
require_once dirname(__FILE__) . DS . 'helper.php';
jimport( 'joomla.application.module.helper' );

 $moduleclass=$params->get('moduleclass');
 $category=$params->get('catshow',0);
 $author=$params->get('showauthor',0);
 $date=$params->get('showcreate',0);
 $modified=$params->get('showmodified',0);
 $desc=$params->get('intro',0);
 $morebtn=$params->get('showreadmore',0);
 $limit=(int)$params->get('limit',20);
 $users=$params->get('users');
 $catsset=$params->get('cats');
 $alltags=$params->get('alltags');

 $filterbg= $params->get('filterbtnbg','#CC0000');
 $filtercolor= $params->get('filterbtncolor','#FFFFFF');
 $filterbghover= $params->get('filterbtnbghover','#009933');
 $filtercolorhover= $params->get('filterbtncolorhover','#FFFFFF');
 $filterbgactive= $params->get('filterbtnbgactive','#666');
 $filtercoloractive= $params->get('filterbtncoloractive','#FFFFFF');
 $titlecolor= $params->get('titlecolor','#000000');
 $readmorebg= $params->get('readmorebg','#008CBA');
 $readmorecolor= $params->get('readmorecolor','#FFFFFF');
 $loadmorebg= $params->get('loadmorebg','#F06000');
 $loadmorecolor= $params->get('loadmorecolor','#FFFFFF');
 $source=modAwesomeportfolioHelper::getSource($params);

if(!empty($catsset) || !empty($users) || !empty($alltags)){

$results= modAwesomeportfolioHelper::getArticles($params);
}

// Display the template
require(JModuleHelper::getLayoutPath('mod_awesomeportfolio'));

?>