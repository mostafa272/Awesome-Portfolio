﻿<?php
/**
* @Author  Mostafa Shahiri
*@license	GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
 defined('_JEXEC') or die();
 JHtml::_('jquery.framework');
 if(!class_exists('ContentHelperRoute'))
 require_once (JPATH_SITE . '/components/com_content/helpers/route.php');

 $document = JFactory::getDocument();
 $document->addScript('modules/mod_awesomeportfolio/js/script.js');
 $document->addScript('modules/mod_awesomeportfolio/js/fetchmore.js');
 $document->addStyleSheet('modules/mod_awesomeportfolio/css/awesomeportfolio.css');
$style="#modportBtnContainer .btn{
background:".$filterbg.";
color:".$filtercolor.";
}
#modportBtnContainer .btn:hover{
background:".$filterbghover.";
color:".$filtercolorhover.";
}
#modportBtnContainer .active{
background:".$filterbgactive.";
color:".$filtercoloractive.";
}
#modern_portfolio h4{
color:".$titlecolor.";
}
a.modport_readmore {
background:".$readmorebg.";
color:".$readmorecolor.";
}
#modport_load{
background:".$loadmorebg.";
color:".$loadmorecolor.":
}
.modcolumn{
float:".$float.";
}
";
$document->addStyleDeclaration($style);


echo '<div id="modern_portfolio" class="'.$moduleclass.'">';
 echo'<div id="modportBtnContainer">';
  echo "<button class=\"btn showall active\" onclick=\"filterSelection('all')\"> Show all</button>";
  foreach($source as $src)
  echo "<button class=\"btn\" onclick=\"filterSelection('class".$src->id."')\">".$src->title."</button>";
 echo '</div>';
echo '<div class="modrow">';
//display posts
echo '<div class="moditems">';
if(!empty($results))
{
 foreach($results as $c)
{
  $images = json_decode($c->images);
  $c_tmp=($category==1)?'<small class="modportinfo">'.JText::_('MOD_AWESOMEPORTFOLIO_CAT').'</small>: <small class="modport_cats">'.$c->catname.'</small></br>':'';
  $a_tmp=($author==1)?'<small class="modportinfo">'.JText::_('MOD_AWESOMEPORTFOLIO_AUTHOR').': '.$c->author.'</small></br>':'';
  $d_tmp=($date==1)?'<small class="modportinfo">'.JText::_('MOD_AWESOMEPORTFOLIO_CREATED').': '.JHtml::_('date',$c->created, JText::_('DATE_FORMAT_LC3')).'</small></br>':'';
  $m_tmp=($modified==1)?'<small class="modportinfo">'.JText::_('MOD_AWESOMEPORTFOLIO_MODIFIED').': '.JHtml::_('date',$c->modified, JText::_('DATE_FORMAT_LC3')).'</small></br>':'';
  $desc_tmp=($desc==1)?'<div>'.JHTML::_('string.truncate',$c->introtext,$limit).'</div>':'';
  $morebtn_tmp= ($morebtn==1)?'<a class="modport_readmore" href="'.JRoute::_(ContentHelperRoute::getArticleRoute($c->id,$c->catid)).'">'.JText::_('MOD_AWESOMEPORTFOLIO_READMORE').'</a>':'';
  $info_block=(!empty($c_tmp.$a_tmp.$d_tmp.$m_tmp))?'<div class="infoblock">'.$c_tmp.$a_tmp.$d_tmp.$m_tmp.'</div>':'';

  echo '<div class="'.$c->classname.'">';
    echo '<div class="modport_content"><div class="modport_container">'.'<div class="modport_img"><img src="'.htmlspecialchars($images->image_intro).'"/></div>'.'<div class="modport_overlay"><a class="modport_imglink" href="'.JRoute::_(ContentHelperRoute::getArticleRoute($c->id,$c->catid)).'"></a></div></div>'.$info_block.'<h4>'.$c->title.'</h4>'.$desc_tmp.$morebtn_tmp;
   echo '</div>';
 echo '</div>';

}

}
echo '</div>';
echo '<div id="load_container"><div id="modport_loading" ><div id="modport_loader"></div><div id="modport_loadtext"> Loading </div></div><button id="modport_load" class=""> Load More</button></div>';
echo '</div>';
echo '</div>';
 ?>
