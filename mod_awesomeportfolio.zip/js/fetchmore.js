jQuery(document).ready(function() {
    jQuery('#modport_loading').hide();

    jQuery('#modport_load').on('click', function(e) {
    e.preventDefault();
   jQuery('#modport_load').hide();
    jQuery('#modport_loading').show();
    var count=jQuery('.modcolumn').length;
    var request= {'option' : 'com_ajax', 'module' : 'awesomeportfolio' , 'portcount':count, 'format':'raw'};
	jQuery.ajax({
		type: "POST",                 // use $_POST request to submit data
		data: request,
		success:function( response ) {
		  jQuery('.moditems').fadeOut(1).html( response ).fadeIn(500); //
          jQuery('#modportBtnContainer .showall').trigger('click');
          jQuery('#modport_loading').hide();
         jQuery('#modport_load').show();
         var newcount=jQuery('.modcolumn').length;
          if(newcount-count == 0)jQuery('#modport_load').fadeOut(500);
		},
		error: function(){
			console.log(errorThrown); // error
		}
	});

    });

});